UCDFR-SUPERVIS
==============
