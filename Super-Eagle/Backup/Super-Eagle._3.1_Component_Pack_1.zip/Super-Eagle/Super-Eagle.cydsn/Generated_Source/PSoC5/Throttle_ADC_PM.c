/*******************************************************************************
* File Name: Throttle_ADC_PM.c
* Version 2.10
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Throttle_ADC.h"


/***************************************
* Local data allocation
***************************************/

static Throttle_ADC_BACKUP_STRUCT  Throttle_ADC_backup =
{
    Throttle_ADC_DISABLED
};


/*******************************************************************************
* Function Name: Throttle_ADC_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Throttle_ADC_SaveConfig(void)
{
    /* All configuration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: Throttle_ADC_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Throttle_ADC_RestoreConfig(void)
{
    /* All congiguration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: Throttle_ADC_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred routine to prepare the component for sleep.
*  The Throttle_ADC_Sleep() routine saves the current component state,
*  then it calls the ADC_Stop() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Throttle_ADC_backup - modified.
*
*******************************************************************************/
void Throttle_ADC_Sleep(void)
{
    if((Throttle_ADC_PWRMGR_SAR_REG  & Throttle_ADC_ACT_PWR_SAR_EN) != 0u)
    {
        if((Throttle_ADC_SAR_CSR0_REG & Throttle_ADC_SAR_SOF_START_CONV) != 0u)
        {
            Throttle_ADC_backup.enableState = Throttle_ADC_ENABLED | Throttle_ADC_STARTED;
        }
        else
        {
            Throttle_ADC_backup.enableState = Throttle_ADC_ENABLED;
        }
        Throttle_ADC_Stop();
    }
    else
    {
        Throttle_ADC_backup.enableState = Throttle_ADC_DISABLED;
    }
}


/*******************************************************************************
* Function Name: Throttle_ADC_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred routine to restore the component to the state when
*  Throttle_ADC_Sleep() was called. If the component was enabled before the
*  Throttle_ADC_Sleep() function was called, the
*  Throttle_ADC_Wakeup() function also re-enables the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Throttle_ADC_backup - used to check enabable state.
*
*******************************************************************************/
void Throttle_ADC_Wakeup(void)
{
    if(Throttle_ADC_backup.enableState != Throttle_ADC_DISABLED)
    {
        Throttle_ADC_Enable();
        #if(Throttle_ADC_DEFAULT_CONV_MODE != Throttle_ADC__HARDWARE_TRIGGER)
            if((Throttle_ADC_backup.enableState & Throttle_ADC_STARTED) != 0u)
            {
                Throttle_ADC_StartConvert();
            }
        #endif /* End Throttle_ADC_DEFAULT_CONV_MODE != Throttle_ADC__HARDWARE_TRIGGER */
    }
}


/* [] END OF FILE */
