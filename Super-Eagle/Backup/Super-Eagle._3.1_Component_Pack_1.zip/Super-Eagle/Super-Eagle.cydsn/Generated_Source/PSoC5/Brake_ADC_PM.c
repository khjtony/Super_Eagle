/*******************************************************************************
* File Name: Brake_ADC_PM.c
* Version 2.10
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Brake_ADC.h"


/***************************************
* Local data allocation
***************************************/

static Brake_ADC_BACKUP_STRUCT  Brake_ADC_backup =
{
    Brake_ADC_DISABLED
};


/*******************************************************************************
* Function Name: Brake_ADC_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Brake_ADC_SaveConfig(void)
{
    /* All configuration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: Brake_ADC_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Brake_ADC_RestoreConfig(void)
{
    /* All congiguration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: Brake_ADC_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred routine to prepare the component for sleep.
*  The Brake_ADC_Sleep() routine saves the current component state,
*  then it calls the ADC_Stop() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Brake_ADC_backup - modified.
*
*******************************************************************************/
void Brake_ADC_Sleep(void)
{
    if((Brake_ADC_PWRMGR_SAR_REG  & Brake_ADC_ACT_PWR_SAR_EN) != 0u)
    {
        if((Brake_ADC_SAR_CSR0_REG & Brake_ADC_SAR_SOF_START_CONV) != 0u)
        {
            Brake_ADC_backup.enableState = Brake_ADC_ENABLED | Brake_ADC_STARTED;
        }
        else
        {
            Brake_ADC_backup.enableState = Brake_ADC_ENABLED;
        }
        Brake_ADC_Stop();
    }
    else
    {
        Brake_ADC_backup.enableState = Brake_ADC_DISABLED;
    }
}


/*******************************************************************************
* Function Name: Brake_ADC_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred routine to restore the component to the state when
*  Brake_ADC_Sleep() was called. If the component was enabled before the
*  Brake_ADC_Sleep() function was called, the
*  Brake_ADC_Wakeup() function also re-enables the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Brake_ADC_backup - used to check enabable state.
*
*******************************************************************************/
void Brake_ADC_Wakeup(void)
{
    if(Brake_ADC_backup.enableState != Brake_ADC_DISABLED)
    {
        Brake_ADC_Enable();
        #if(Brake_ADC_DEFAULT_CONV_MODE != Brake_ADC__HARDWARE_TRIGGER)
            if((Brake_ADC_backup.enableState & Brake_ADC_STARTED) != 0u)
            {
                Brake_ADC_StartConvert();
            }
        #endif /* End Brake_ADC_DEFAULT_CONV_MODE != Brake_ADC__HARDWARE_TRIGGER */
    }
}


/* [] END OF FILE */
