/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "state_event.h"
#include "dash_board.h"


void action_startup(){
    return;
}

void action_neutral(){
    return;
}

void action_drive(){
    return;
}   //display, and put 


void action_precharge(){
    return;
}

void action_charging(){
    return;
}

void action_soft_fault(){
    return;
}

void action_hard_fault(){
    return;
}




void reset_drive_sound(){
    return;
}


void reset_precharge_timer(){
    return;   
}

void reset_fault_sound(){
    return;
}

Events get_CAN_error(){

    return NONE;
}



/* [] END OF FILE */
